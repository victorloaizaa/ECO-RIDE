package com.ecoride.ms_calificaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCalificacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
